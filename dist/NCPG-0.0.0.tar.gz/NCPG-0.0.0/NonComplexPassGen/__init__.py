 #import os 
#directory_path = "/path/to/your/directory"
#D:\project\4passwordGen\NonComplexPassGen

 
# Ensure the directory exists
#os.makedirs(directory_path, exist_ok=True)

# Create an empty __init__.py file
#with open(os.path.join(directory_path, "__init__.py"), "w"):
#from main.py import main